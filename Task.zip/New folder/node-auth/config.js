module.exports = {
    secretKey: process.env.SECRET_KEY || 'saif123098',
  };
  